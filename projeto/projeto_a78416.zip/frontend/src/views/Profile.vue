<template>
  <v-container>
    <v-layout>
      <v-flex xs12>
        <profile/>
      </v-flex>
    </v-layout>
    <v-layout>
      <v-flex xs2/>
      <v-flex xs8>
        <profileEdit/>
      </v-flex>
      <v-flex xs2/>
    </v-layout>
  </v-container>
</template>

<script>
  import profile from '@/components/profile'
  import profileEdit from '@/components/profileEdit'

  export default {
    mounted: async function (){
      // redirect to root if not already logged in
      if(!this.$session.has('id'))
        this.$router.push('/')
    },
    components: {
      profile,
      profileEdit
    }
  }
</script>
