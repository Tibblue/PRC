<template>
  <Index/>
</template>

<script>
  import Index from '@/components/Index'

  export default {
    components: {
      Index
    }
  }
</script>
